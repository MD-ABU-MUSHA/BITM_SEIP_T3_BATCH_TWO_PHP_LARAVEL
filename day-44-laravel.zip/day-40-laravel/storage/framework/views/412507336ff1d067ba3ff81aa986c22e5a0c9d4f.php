</body>
</html>
<?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/includes/footer.blade.php ENDPATH**/ ?>