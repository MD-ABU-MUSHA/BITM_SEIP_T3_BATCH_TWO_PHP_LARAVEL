
<?php $__env->startSection('title'); ?>
    Add New Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12 ">
                    <div class="card">
                        <div class="card-header text-center">
                            <h3>Add  Blog Information</h3>
                        </div>
                        <div class="card-body">
                            <?php if($message = Session::get('message')): ?>
                                <h3 class="text-center text-success"><?php echo e($message); ?></h3>
                            <?php endif; ?>
                           <table class="table table-bordered table-hover">
                               <thead class="text-center">
                               <tr >
                                   <th>SL No</th>
                                   <th>Blog Title</th>
                                   <th>Blog Author</th>
                                   <th>Blog Image</th>
                                   <th>Blog Description</th>
                                   <th>Action</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="text-center">
                                   <td><?php echo e($loop->iteration); ?></td>
                                   <td><?php echo e($blog->title); ?></td>
                                   <td><?php echo e($blog->author); ?></td>
                                   <td><img src="<?php echo e(asset($blog->image)); ?>" alt="" height="200" width="200"/> </td>
                                   <td><?php echo e($blog->description); ?></td>
                                   <td>
                                       1
                                   </td>
                               </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/blog/manage.blade.php ENDPATH**/ ?>