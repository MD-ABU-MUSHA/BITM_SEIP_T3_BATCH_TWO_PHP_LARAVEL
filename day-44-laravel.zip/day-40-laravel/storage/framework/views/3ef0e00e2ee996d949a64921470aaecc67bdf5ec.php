<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<section class="py-5">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mx-auto">
                <div class="card ">
                    <img src="<?php echo e(asset($product['image'])); ?>" alt="" class="card-img-top" height="400" width=""300>
                    <div class="card-body">
                        <h5>Product Name : <?php echo e($product['name']); ?></h5>
                        <h5>Product Price: <?php echo e($product['price']); ?> </h5>
                    </div>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/home.blade.php ENDPATH**/ ?>