<script src="../assete/js/jquery-3.6.0.js"></script>
<script src="../assete/js/bootstrap.js"></script>
</body>
</html>