
<?php $__env->startSection('title'); ?>
    Edit Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="card">
                        <div class="card-header text-center">
                            <h3>Edit Blog Form</h3>
                        </div>
                        <div class="card-body">
                            <?php if($message = Session::get('message')): ?>
                                <h3 class="text-center text-success"><?php echo e($message); ?></h3>
                            <?php endif; ?>
                            <form action="<?php echo e(route('update-blog')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($blog->id); ?>" name="id">
                                <div class="form-group row">
                                    <label for="" class="col-form-label col-md-3 text-center">Blog Title</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($blog->title); ?>" class="form-control" name="title">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-form-label col-md-3 text-center">Author Name</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($blog->author); ?>" class="form-control" name="author">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-form-label col-md-3 text-center">Blog Description</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control"  name="description"><?php echo e($blog->description); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-form-label col-md-3 text-center">Image</label>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="image">
                                        <img src="<?php echo e(asset($blog->image)); ?>" alt="" height="100" width="100">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-form-label col-md-3 text-center"></label>
                                    <div class="col-md-9">
                                        <input type="submit" class="btn btn-outline-success" name="btn" value="Update Blog Info"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/blog/edit.blade.php ENDPATH**/ ?>