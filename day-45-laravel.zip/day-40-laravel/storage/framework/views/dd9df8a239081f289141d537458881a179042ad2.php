
<?php $__env->startSection('title'); ?>
    Add New Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
       <section class="py-5 bg-light">
           <div class="container">
               <div class="row">
                   <div class="col-md-8 col-md-offset-2">
                       <div class="card">
                           <div class="card-header text-center">
                               <h3>Add New Blog Form</h3>
                           </div>
                           <div class="card-body">
                               <?php if($message = Session::get('message')): ?>
                                   <h3 class="text-center text-success"><?php echo e($message); ?></h3>
                                   <?php endif; ?>
                               <form action="<?php echo e(route('new-blog')); ?>" method="POST" enctype="multipart/form-data">
                                   <?php echo csrf_field(); ?>
                                   <div class="form-group row">
                                       <label for="" class="col-form-label col-md-3 text-center">Blog Title</label>
                                       <div class="col-md-9">
                                           <input type="text" class="form-control" name="title">
                                       </div>
                                   </div>
                                   <div class="form-group row">
                                       <label for="" class="col-form-label col-md-3 text-center">Author Name</label>
                                       <div class="col-md-9">
                                           <input type="text" class="form-control" name="author">
                                       </div>
                                   </div>
                                   <div class="form-group row">
                                       <label for="" class="col-form-label col-md-3 text-center">Blog Description</label>
                                       <div class="col-md-9">
                                           <textarea class="form-control" name="description"></textarea>
                                       </div>
                                   </div>
                                   <div class="form-group row">
                                       <label for="" class="col-form-label col-md-3 text-center">Image</label>
                                       <div class="col-md-9">
                                           <input type="file" class="form-control" name="image">
                                       </div>
                                   </div>
                                   <div class="form-group row">
                                       <label for="" class="col-form-label col-md-3 text-center"></label>
                                       <div class="col-md-9">
                                           <input type="submit" class="btn btn-outline-success" name="btn" value="Create New Blog"/>
                                       </div>
                                   </div>
                               </form>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/blog/add.blade.php ENDPATH**/ ?>