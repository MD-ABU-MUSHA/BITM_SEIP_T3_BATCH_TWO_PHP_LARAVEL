<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<section class="py-5 bg-info">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <a href="<?php echo e(route('category.show', $category['id'])); ?>" class="btn btn-link">
                <div class="card card-body">
                    <h4 class="text-center"><?php echo e($category['name']); ?></h4>
                </div>
                </a>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/all-category.blade.php ENDPATH**/ ?>