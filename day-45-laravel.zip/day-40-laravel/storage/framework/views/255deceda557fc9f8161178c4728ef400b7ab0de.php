
<h3>Hello demo</h3>


<a href="<?php echo e(route('basis')); ?>">BITM SEIP</a>
||
<a href="">Home</a>
||
<a href="">BITM</a>
||

<h3>Hello BITM</h3>


<a href="<?php echo e(route('basis')); ?>">BITM SEIP</a>||
<a href="">Home</a> ||
<a href="">BITM</a> ||

<a href="">ALL Category</a><?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/demo.blade.php ENDPATH**/ ?>