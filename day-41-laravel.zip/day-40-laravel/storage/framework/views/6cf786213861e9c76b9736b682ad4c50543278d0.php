<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<section content="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card card-body">
                    <form action="<?php echo e(route('count')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="" class="col-form-label col-md-3">Enter Your String</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="given_string"/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-form-label col-md-3">Result</label>
                            <div class="col-md-9">
                                <textarea cols="30" rows="10" readonly class="form-control"><?php echo e(isset($word) ? $word : ' '); ?> <?php echo e("\n"); ?><?php echo e(isset($character) ? $character : ' '); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-form-label col-md-3"></label>
                            <div class="col-md-9">
                                <input type="submit" class="btn btn-outline-success btn-block" name="btn" value="Submit"   />
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>





<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/count.blade.php ENDPATH**/ ?>