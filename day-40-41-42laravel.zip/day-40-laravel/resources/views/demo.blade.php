
<h3>Hello demo</h3>


<a href="{{ route('basis') }}">BITM SEIP</a>
||
<a href="">Home</a>
||
<a href="">BITM</a>
||

<h3>Hello BITM</h3>


<a href="{{ route('basis') }}">BITM SEIP</a>||
<a href="">Home</a> ||
<a href="">BITM</a> ||

<a href="">ALL Category</a>