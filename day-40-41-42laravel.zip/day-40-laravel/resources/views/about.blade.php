@include('includes.header');



<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card card-body">
                    <h1 class="card-title">This is About Page</h1>
                </div>
            </div>
        </div>
    </div>
</section>

@include('includes.footer');