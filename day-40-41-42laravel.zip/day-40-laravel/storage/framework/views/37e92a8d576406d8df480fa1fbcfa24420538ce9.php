<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.css')); ?>"/>
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <a href="" class="navbar-brand">LOGO</a>
        <ul class="navbar-nav">
            <li><a href="<?php echo e(route('Bitm')); ?>" class="nav-link">Home</a></li>
            <li><a href="<?php echo e(route('count')); ?>" class="nav-link">Count</a></li>
            
            <li><a href="<?php echo e(route('odd-even')); ?>" class="nav-link">Odd-Even</a></li>
            <li><a href="<?php echo e(route('registration')); ?>" class="nav-link">Registration</a></li>
            <li><a href="<?php echo e(route('prime')); ?>" class="nav-link">Prime</a></li>
            <li><a href="<?php echo e(route('category.index')); ?>" class="nav-link">All Category</a></li>
            <li><a href="" class="nav-link">Manage Category</a></li>
            <li><a href="" class="nav-link">Login</a></li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/includes/header.blade.php ENDPATH**/ ?>