<!DOCTYPE html>
<html lang="zxx">

<head>
    <?php echo $__env->make('front.includes.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Urdan - <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('front.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>




<body>
<div class="main-wrapper main-wrapper-2">
   <?php echo $__env->make('front.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('body'); ?>
    <?php echo $__env->make('front.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
    <?php echo $__env->make('front.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\php_laravel_musha\urdan-ecommerce-project\resources\views/front/master.blade.php ENDPATH**/ ?>