
<script src="<?php echo e(asset('/')); ?>js/jquery.js"></script>
<script src="<?php echo e(asset('/')); ?>js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/')); ?>js/jquery.scrollUp.min.js"></script>
<script src="<?php echo e(asset('/')); ?>js/price-range.js"></script>
<script src="<?php echo e(asset('/')); ?>js/jquery.prettyPhoto.js"></script>
<script src="<?php echo e(asset('/')); ?>js/main.js"></script><?php /**PATH C:\xampp\htdocs\php_laravel_musha\day-40-laravel\resources\views/front/includes/script.blade.php ENDPATH**/ ?>