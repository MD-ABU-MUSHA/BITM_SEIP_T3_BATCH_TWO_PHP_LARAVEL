
<script src="{{asset('/')}}js/jquery.js"></script>
<script src="{{asset('/')}}js/bootstrap.min.js"></script>
<script src="{{asset('/')}}js/jquery.scrollUp.min.js"></script>
<script src="{{asset('/')}}js/price-range.js"></script>
<script src="{{asset('/')}}js/jquery.prettyPhoto.js"></script>
<script src="{{asset('/')}}js/main.js"></script>